import UIKit

func saveTheOne(n:Int,k:Int){
    
}
