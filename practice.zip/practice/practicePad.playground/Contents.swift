import UIKit

var str = "Hello, playground"

func countDigit(n:Int) -> Int{
    return n < 10 ? 1 : 1 + countDigit(n: n/10)
}

countDigit(n: 3)
