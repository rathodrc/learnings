import UIKit

func fibonacci(n:Int) -> Int {
    if n == 0  {return 0}
    if n == 1 || n == 2 {return 1}
    return fibonacci(n: (n-1)) + fibonacci(n: (n-2))
}
fibonacci(n: 20)
