import UIKit

func digiSum(n:Int) -> Int {
    let count = n < 10 ? n : n%10 + digiSum(n: n/10)
    return count < 10 ? count : count%10 + digiSum(n: count/10)
}
digiSum(n:2913)
